
▗▖  ▗▖ ▗▄▖ ▗▖  ▗▖ ▗▄▖ ▗▖ ▗▖▗▄▄▄▖▗▄▄▖ ▗▄▄▄▖
▐▛▚▞▜▌▐▌ ▐▌▐▛▚▖▐▌▐▌ ▐▌▐▌ ▐▌  █  ▐▌ ▐▌▐▌   
▐▌  ▐▌▐▌ ▐▌▐▌ ▝▜▌▐▌ ▐▌▐▌ ▐▌  █  ▐▛▀▚▖▐▛▀▀▘
▐▌  ▐▌▝▚▄▞▘▐▌  ▐▌▝▚▄▞▘▐▙█▟▌▗▄█▄▖▐▌ ▐▌▐▙▄▄▖

————————————————————————————

Thanks for downloading MONOWIRE

monowire.otf / Version 2.0 / March 31, 2026



ABOUT THIS FONT
———————————————

This font was inspired by cyberpunk aesthetics and was designed on an 8×5 grid. Apologies that there are no numbers or punctuation. I hope to make updates and additions in the future. Feedback and general comments are welcomed! 

View a demonstration at: https://mattcolewilson.com/monowire

Visit mattcolewilson.com for more.



TERMS OF USE
————————————

This font is completely free for both personal and commercial use. The distribution of this font for financial gain or profit is not permitted under any circumstances. Free distribution is allowed, if you link back to my site: https://mattcolewilson.com/resources

If you have any questions or comments, please email me!



CONTACT INFORMATION
———————————————————

Email: mattcolewilson@gmail.com

Web: https://mattcolewilson.com


